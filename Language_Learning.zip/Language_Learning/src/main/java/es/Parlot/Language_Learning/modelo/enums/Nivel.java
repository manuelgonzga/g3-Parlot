package es.Parlot.Language_Learning.modelo.enums;

public enum Nivel {
    Principiante, Intermedio, Avanzado,Nativo;
}
