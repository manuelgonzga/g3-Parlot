package es.Parlot.Language_Learning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LanguageLearningApplication {

	public static void main(String[] args) {
		SpringApplication.run(LanguageLearningApplication.class, args);
	}

}