package es.Parlot.Language_Learning.modelo.enums;

public enum rol {
    ROLE_ADMIN, ROLE_STUDENT, ROLE_TEACHER;
}
